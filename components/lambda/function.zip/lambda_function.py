import os
import json
import boto3

def lambda_handler(event, context):
    # Extract the order from the event
    order = event.get('order', 'No order provided')
    
    # Create an SNS client
    sns = boto3.client('sns')
    
    # Define your SNS Topic ARN here
    #topic_arn = "arn:aws:sns:eu-central-1:111111111111:order"
    topic_arn = os.environ['SNS_TOPIC_ARN']
    
    # Publish the message to SNS
    response = sns.publish(
        TopicArn=topic_arn,
        Message=f"New order received: {order}",
        Subject="New Order Notification"  # Optional, can add a subject for the message
    )
    
    # Return the response from SNS
    return {
        'statusCode': 200,
        'body': json.dumps('Order sent successfully'),
        'sns_response': response
    }